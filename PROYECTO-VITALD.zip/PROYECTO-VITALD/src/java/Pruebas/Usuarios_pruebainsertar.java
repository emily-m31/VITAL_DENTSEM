package Pruebas;

import Controlador.UsuariosDAO;
import Modelo.Usuarios;
import java.sql.SQLException;
import java.util.Scanner;

public class Usuarios_pruebainsertar {

    public static void main(String[] args) throws SQLException {

        Scanner sc = new Scanner(System.in);
        Usuarios usuarios = new Usuarios();
        UsuariosDAO dao = new UsuariosDAO();

        System.out.print("Ingrese el nombre del Usuario: ");
        usuarios.setnombreus(sc.nextLine());

        System.out.print("Ingrese el apellido del Usuario: ");
        usuarios.setapellido(sc.nextLine());

        System.out.print("Ingrese el documento del Usuario: ");
        usuarios.setdocumento(sc.nextLine());

        System.out.print("Ingrese el telefono del Usuario: ");
        usuarios.settelefono(sc.nextLine());

        System.out.print("Ingrese el correo del Usuario: ");
        usuarios.setcorreo(sc.nextLine());

        System.out.print("Ingrese una contraseña segura: ");
        usuarios.setcontrasena(sc.nextLine());

        System.out.print("Ingrese Tipo de documento: ");
        usuarios.setTipo_documento_id_Tipodocumento(sc.nextInt());

        System.out.print("Ingrese su tipo de usuario: ");
        usuarios.setRol_id_Rol(sc.nextInt());
        sc.nextLine();

        boolean resultado = dao.insertarUsuarios(usuarios);

        if (resultado) {
            System.out.println("\nEl Usuario se guardo correctamente en VITALEM.");
        } else {
            System.out.println("\nEl usuario no se guardo.");
        }

       
    }
}