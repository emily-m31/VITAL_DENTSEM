/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Pruebas;

/**
 *
 * @author Aprendiz
 */
public class Usuarios_pruebaconsultar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
         Usuarios usuario = dao.consultaUsuarios(1);

        if (usuario != null) {
            System.out.println("Usuario encontrado");
            System.out.println("Nombre: " + usuario.getnombreus());
        } else {
            System.out.println("Usuario no encontrado");
        }
    }
    
}
