/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Pruebas;

import Modelo.Usuarios;

/**
 *
 * @author Aprendiz
 */
public class Usuarios_pruebaactualizar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("\nActualizar usuario");
        System.out.print("ID del usuario a modificar: ");
        int idMod = sc.nextInt();
        sc.nextLine();

        Usuarios usuMod = new Usuarios();
        usuMod.setid_Usuarios(idMod);

        System.out.print("Nuevo Nombre: ");
        usuMod.setnombreus(sc.nextLine());

        System.out.print("Nuevo Apellido: ");
        usuMod.setapellido(sc.nextLine());

        System.out.print("Nuevo Numero de Documento: ");
        usuMod.setdocumento(sc.nextLine());

        System.out.print("Nuevo Telefono: ");
        usuMod.settelefono(sc.nextLine());

        System.out.print("Nuevo Correo: ");
        usuMod.setcorreo(sc.nextLine());

        System.out.print("Nueva contraseña: ");
        usuMod.setcontrasena(sc.nextLine());

        System.out.print("Nuevo Tipo de Documento: ");
        usuMod.setTipo_documento_id_Tipodocumento(sc.nextLine());

        System.out.print("Nuevo tipo de usuario: ");
        usuMod.setRol_id_rol(sc.nextInt());

        if (dao.actualizarUsuario(usuMod)) {
            System.out.println("Usuario actualizado correctamente.");
        }
        // TODO code application logic here
    }
    
}
