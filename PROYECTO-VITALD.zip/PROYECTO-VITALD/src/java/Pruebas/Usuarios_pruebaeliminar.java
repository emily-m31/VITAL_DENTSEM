






 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Pruebas;

/**
 *
 * @author Aprendiz
 */
public class Usuarios_pruebaeliminar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      System.out.println("\nEliminar Usuario");
        System.out.print("ID del usuario a eliminar: ");
        int idDel = sc.nextInt();

        if (dao.eliminarUsuario(idDel)) {
            System.out.println("Usuario eliminado con exito.");
        } else {
            System.out.println("No se encontró el usuario.");
        }  // TODO code application logic here
    }
    
}
