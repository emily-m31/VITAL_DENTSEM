/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Pruebas;

import Modelo.Tipo_documento;

/**
 *
 * @author Aprendiz
 */
public class Tipodocumento_pruebaconsultar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
         Tipo_documento tipo_documento = dao.consultaTipo_documento(1);

        if (tipo_documento != null) {
            System.out.println("Tipo de documento encontrado");
            System.out.println("Nombre: " + tipo_documento.getdescripcion_tipodoc());
        } else {
            System.out.println("Tipo de documento no encontrado");
        }
    }
    
}
