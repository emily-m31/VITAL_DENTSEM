/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Pruebas;


import Controlador.Tipo_tratamientoDAO;
import Modelo.Tipo_tratamiento;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author Aprendiz
 */
public class Tipotratamiento_pruebainsertar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        
        Scanner sc = new Scanner(System.in);

         Tipo_tratamiento tipo_tratamiento = new Tipo_tratamiento();
         Tipo_tratamientoDAO dao = new Tipo_tratamientoDAO();

          System.out.print("Ingrese el ID del tipo de tratamiento: ");
          tipo_tratamiento.setid_Tipotratam(Integer.parseInt(sc.nextLine()));

          System.out.print("Ingrese la descripción del tipo de tratamiento: ");
          tipo_tratamiento.setdescripcion_tipotratam(sc.nextLine());

          System.out.print("Ingrese el costo del tratamiento: ");
          tipo_tratamiento.setcosto(sc.nextLine());

          boolean resultado = dao.insertarTipo_tratamiento(tipo_tratamiento);

          if (resultado) {
          System.out.println("El tipo de tratamiento se guardó correctamente.");
          } else {
          System.out.println("El tipo de tratamiento no se guardó.");
}
    }
}