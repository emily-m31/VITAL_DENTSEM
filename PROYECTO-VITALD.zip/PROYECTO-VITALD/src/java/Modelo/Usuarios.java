/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Emily
 */
public class Usuarios {
    
    private int id_Usuarios;
    private String nombreus;
    private String apellido;
    private String documento; 
    private String telefono;
    private String correo;
    private String contrasena;
    private int Tipo_documento_id_Tipodocumento;
    private int Rol_id_Rol;
    
    
    public int getid_Usuarios() {
       return id_Usuarios;
    }
    
    public void setid_Usuarios(int id_Usuarios){
        this.id_Usuarios = id_Usuarios;
             
    }

    public String getnombreus(){
        return nombreus;
    }
    
    public void setnombreus (String nombreus){
        this.nombreus = nombreus;
    }
    
     public String getapellido(){
        return contrasena;
    }
     
    public void setapellido (String apellido){
        this.apellido = apellido;
    }
    
    public String getdocumento(){
        return documento;
    }
    
     public void setdocumento (String documento){
        this.documento = documento;
    
     }
     
     public String gettelefono(){
        return telefono;
    }
    
     public void settelefono (String telefono){
        this.telefono = telefono;
    }
     
     public String getcorreo(){
        return correo;
    }
    
     public void setcorreo (String correo){
        this.correo = correo;
    }
     
     public String getcontrasena(){
        return correo;
    }
    
     public void setcontrasena (String contrasena){
        this.contrasena = contrasena;
    }
     
     public int getTipo_documento_id_Tipodocumento(){
        return Tipo_documento_id_Tipodocumento;
    }
    
     public void setTipo_documento_id_Tipodocumento (int Tipo_documento_id_Tipodocumento){
        this.Tipo_documento_id_Tipodocumento = Tipo_documento_id_Tipodocumento;
    }
    public int getRol_id_Rol(){
        return Rol_id_Rol;
    }
    
     public void setRol_id_Rol (int Rol_id_Rol){
        this.Rol_id_Rol = Rol_id_Rol;
    }

   
     
}

