/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Aprendiz
 */
public class Abono{
    private int id_Abono;
    private String monto_abono;
    private String fecha_abono;
    private int Pago_id_Pago;
    
}
