/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;


import Modelo.Tipo_tratamiento;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Aprendiz
 */
public class Tipo_tratamientoDAO {
       Conexion conexion = new Conexion();

   public boolean insertarTipo_tratamiento(Tipo_tratamiento tipo_tratamiento) throws SQLException {
    boolean insertado = false;
    String sql = "INSERT INTO tipo_tratamiento (id_Tipotratam, descripcion_tipotratam, costo) VALUES (?, ?, ?)";
    
    try (Connection con = conexion.getConn();
         PreparedStatement ps = con.prepareStatement(sql)) {
        
        ps.setInt(1, tipo_tratamiento.getid_Tipotratam());
        ps.setString(2, tipo_tratamiento.getdescripcion_tipotratam());
        ps.setString(3, tipo_tratamiento.getcosto());

        int filasAfectadas = ps.executeUpdate();
        if (filasAfectadas > 0) {
            insertado = true;
            System.out.println("Tipo de tratamiento insertado con exito.");
        }
        
    } catch (SQLException e) {
        System.err.println("Error al insertar tipo de tratamiento: " + e.getMessage());
    }
    return insertado;
}
    
    
    
    public Tipo_tratamiento consultaTipo_tratamiento(int id_Tipotratam) {

        Tipo_tratamiento tipo_tratamiento = null;
        Conexion conexion = new Conexion();
        Connection con = conexion.getConn();

        try {

            String querySQL = "SELECT id_Tipotratam, descripcion_tipotratam FROM Tipo_tramiento WHERE id_Tipotratam = ? ";

            PreparedStatement ps = con.prepareStatement(querySQL);
            ps.setInt(1, id_Tipotratam);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                tipo_tratamiento = new Tipo_tratamiento();
                tipo_tratamiento.setid_Tipotratam(rs.getInt(1));
                tipo_tratamiento.setdescripcion_tipotratam(rs.getString(2));
                tipo_tratamiento.setcosto(rs.getString(3));
            }

            return tipo_tratamiento;

        } catch (Exception ex) {

            System.out.println(ex.getMessage());
            return tipo_tratamiento;

        }
    }
    
  public boolean actualizarTipo_tratamiento(Tipo_tratamiento tipo_tratamiento) throws SQLException {
        boolean actualizado = false;
        String sql = "UPDATE Tipo_tratamiento SET descripcion_tipotratam=? WHERE id_Tipotratam=?";
        Conexion conexion = new Conexion();
        Connection con = (Connection) conexion.getConn();

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, tipo_tratamiento.getdescripcion_tipotratam());
 
            if (ps.executeUpdate() > 0) {
                actualizado = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar el tipo de tratamiento: " + e.getMessage());
        }
        return actualizado;
    }


    public boolean eliminarTipo_tratamiento(int id) throws SQLException {
        boolean eliminado = false;
        String sql = "DELETE FROM tipo_tratamiento WHERE id_Tipotratam = ?";
        Conexion conexion = new Conexion();
        Connection con = (Connection) conexion.getConn();

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            if (ps.executeUpdate() > 0) {
                eliminado = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar el tipo de tratamiento  " + e.getMessage());
        }
        return eliminado;
    }
}  
