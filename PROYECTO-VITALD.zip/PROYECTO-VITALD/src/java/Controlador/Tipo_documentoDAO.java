/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Tipo_documento;
import Modelo.Usuarios;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Aprendiz
 */
public class Tipo_documentoDAO {
       Conexion conexion = new Conexion();

   public boolean insertarTipo_documento(Tipo_documento tipo_documento) throws SQLException {
    boolean insertado = false;
    String sql = "INSERT INTO tipo_documento (id_Tipodocumento, descripcion_tipodoc) VALUES (?, ?)";
    
    try (Connection con = conexion.getConn();
         PreparedStatement ps = con.prepareStatement(sql)) {
        
        ps.setInt(1, tipo_documento.getid_Tipodocumento());
        ps.setString(2, tipo_documento.getdescripcion_tipodoc());

        int filasAfectadas = ps.executeUpdate();
        if (filasAfectadas > 0) {
            insertado = true;
            System.out.println("Tipo documento insertado con exito.");
        }
        
    } catch (SQLException e) {
        System.err.println("Error al insertar tipo de documento: " + e.getMessage());
    }
    return insertado;
}
    
    
    
    public Tipo_documento consultaTipo_documento(int id_Tipodocumento) {

        Tipo_documento tipo_documento = null;
        Conexion conexion = new Conexion();
        Connection con = conexion.getConn();

        try {

            String querySQL = "SELECT id_Tipodocumento, descripcion_tipodoc FROM Tipo_documento WHERE id_Tipodocumento = ? ";

            PreparedStatement ps = con.prepareStatement(querySQL);
            ps.setInt(1, id_Tipodocumento);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                tipo_documento = new Tipo_documento();
                tipo_documento.setid_Tipodocumento(rs.getInt(1));
                tipo_documento.setdescripcion_tipodoc(rs.getString(2));
            }

            return tipo_documento;

        } catch (Exception ex) {

            System.out.println(ex.getMessage());
            return tipo_documento;

        }
    }
    
  public boolean actualizarUsuario(Tipo_documento tipo_documento) throws SQLException {
        boolean actualizado = false;
        String sql = "UPDATE Tipo_documento SET descripcion_tipodoc=? WHERE id_Tipodocumento=?";
        Conexion conexion = new Conexion();
        Connection con = (Connection) conexion.getConn();

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, tipo_documento.getdescripcion_tipodoc());

            if (ps.executeUpdate() > 0) {
                actualizado = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar el tipo de documento: " + e.getMessage());
        }
        return actualizado;
    }


    public boolean eliminarTipo_documento(int id) throws SQLException {
        boolean eliminado = false;
        String sql = "DELETE FROM tipo_documento WHERE id_Tipodocumento = ?";
        Conexion conexion = new Conexion();
        Connection con = (Connection) conexion.getConn();

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            if (ps.executeUpdate() > 0) {
                eliminado = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar el tipo de documento  " + e.getMessage());
        }
        return eliminado;
    }
}  
    

