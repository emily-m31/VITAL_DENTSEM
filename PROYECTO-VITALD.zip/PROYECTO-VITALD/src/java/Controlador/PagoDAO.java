/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;


import Modelo.Pago;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Aprendiz
 */
public class PagoDAO {
       Conexion conexion = new Conexion();

   public boolean insertarPago(Pago pago) throws SQLException {
    boolean insertado = false;
    String sql = "INSERT INTO pago (id_Pago, monto, Medio_pago_id_Mediodepago, Estado_pago_id_Estadopago, Cita_id_Cita) VALUES (?, ?, ?, ?, ?)";
    
    try (Connection con = conexion.getConn();
         PreparedStatement ps = con.prepareStatement(sql)) {
        
        ps.setInt(1, pago.getid_Pago());
        ps.setString(2, pago.getmonto());
        ps.setInt(3, pago.getMedio_pago_id_Mediodepago());
        ps.setInt(4, pago.getEstado_pago_id_Estadopago());
        ps.setInt(5, pago.getCita_id_Cita());

        int filasAfectadas = ps.executeUpdate();
        if (filasAfectadas > 0) {
            insertado = true;
            System.out.println("Pago insertado con exito.");
        }
        
    } catch (SQLException e) {
        System.err.println("Pago: " + e.getMessage());
    }
    return insertado;
}
    
    
    
    public Pago consultaPago(int id_Pago, String monto, int Medio_pago_id_Mediopago, int Estado_pago_id_Estadopago, int Cita_id_Cita) {

        Pago pago = null;
        Conexion conexion = new Conexion();
        Connection con = conexion.getConn();

        try {

            String querySQL = "SELECT id_Pago, monto, Medio_pago_id_Mediopago, Estado_pago_id_Estadopago, Cita_id_Cita FROM Pago WHERE id_Pago = ?, ?, ?, ?, ? ";

            PreparedStatement ps = con.prepareStatement(querySQL);
            ps.setInt(1, id_Pago);
            ps.setString(2, monto);
            ps.setInt(3, Medio_pago_id_Mediopago);
            ps.setInt(4, Estado_pago_id_Estadopago);
            ps.setInt(5, Cita_id_Cita);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                pago = new Pago();
                pago.setid_Pago(rs.getInt(1));
                pago.setmonto(rs.getString(2));
                pago.setMedio_pago_id_Mediopago(rs.getInt(3));
                pago.setEstado_pago_id_Estadopago(rs.getInt(4));
                pago.setCita_id_Cita(rs.getInt(5));
            }

            return tipo_tratamiento;

        } catch (Exception ex) {

            System.out.println(ex.getMessage());
            return tipo_tratamiento;

        }
    }
    
  public boolean actualizarTipo_tratamiento(Tipo_tratamiento tipo_tratamiento) throws SQLException {
        boolean actualizado = false;
        String sql = "UPDATE Tipo_tratamiento SET descripcion_tipotratam=? WHERE id_Tipotratam=?";
        Conexion conexion = new Conexion();
        Connection con = (Connection) conexion.getConn();

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, tipo_tratamiento.getdescripcion_tipotratam());
 
            if (ps.executeUpdate() > 0) {
                actualizado = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar el tipo de tratamiento: " + e.getMessage());
        }
        return actualizado;
    }


    public boolean eliminarTipo_tratamiento(int id) throws SQLException {
        boolean eliminado = false;
        String sql = "DELETE FROM tipo_tratamiento WHERE id_Tipotratam = ?";
        Conexion conexion = new Conexion();
        Connection con = (Connection) conexion.getConn();

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            if (ps.executeUpdate() > 0) {
                eliminado = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar el tipo de tratamiento  " + e.getMessage());
        }
        return eliminado;
    }
}  
