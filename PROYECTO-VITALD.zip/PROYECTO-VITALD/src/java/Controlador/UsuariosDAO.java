/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import Modelo.Usuarios;
import java.util.List;
import java.sql.ResultSet;

/**
 *
 * @author Aprendiz
 */
public class UsuariosDAO {

    Conexion conexion = new Conexion();

   public boolean insertarUsuarios(Usuarios usuarios) throws SQLException {
    boolean insertado = false;
    String sql = "INSERT INTO usuarios (id_Usuarios, nombreus, apellido, documento, telefono, correo, contrasena, Tipo_documento_id_Tipodocumento, Rol_id_Rol) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    try (Connection con = conexion.getConn();
         PreparedStatement ps = con.prepareStatement(sql)) {
        
        ps.setInt(1, usuarios.getid_Usuarios());
        ps.setString(2, usuarios.getnombreus());
        ps.setString(3, usuarios.getapellido());
        ps.setString(4, usuarios.getdocumento());
        ps.setString(5, usuarios.gettelefono());
        ps.setString(6, usuarios.getcorreo());
        ps.setString(7, usuarios.getcontrasena());
        ps.setInt(8, usuarios.getTipo_documento_id_Tipodocumento());
        ps.setInt(9, usuarios.getRol_id_Rol());

        int filasAfectadas = ps.executeUpdate();
        if (filasAfectadas > 0) {
            insertado = true;
            System.out.println("Usuario insertado con éxito.");
        }
        
    } catch (SQLException e) {
        System.err.println("Error al insertar usuario: " + e.getMessage());
    }
    return insertado;
}
    
    
    
    public Usuarios consultaUsuarios(int id_Usuarios) {

        Usuarios usuario = null;
        Conexion conexion = new Conexion();
        Connection con = conexion.getConn();

        try {

            String querySQL = "SELECT id_Usuarios, nombreus, apellido, documento, telefono, correo, contrasena, Tipo_documento_id_Tipodocumento, Rol_id_rol";

            PreparedStatement ps = con.prepareStatement(querySQL);
            ps.setInt(1, id_Usuarios);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                usuario = new Usuarios();
                usuario.setid_Usuarios(rs.getInt(1));
                usuario.setnombreus(rs.getString(2));
                usuario.setapellido(rs.getString(3));
                usuario.setdocumento(rs.getString(4));
                usuario.settelefono(rs.getString(5));
                usuario.setcorreo(rs.getString(6));
                usuario.setcontrasena(rs.getString(7));
                usuario.setTipo_documento_id_Tipodocumento(rs.getInt(8));
                usuario.setRol_id_Rol(rs.getInt(9));
            }

            return usuario;

        } catch (Exception ex) {

            System.out.println(ex.getMessage());
            return usuario;

        }
    }
    
  public boolean actualizarUsuario(Usuarios usuarios) throws SQLException {
        boolean actualizado = false;
        String sql = "UPDATE usuarios SET nombreus=?, apellido=?, documento=?, telefono=?, correo=?, contrasena=?, id_Tipodocumento=?, id_Rol=? WHERE idUsuarios=?";
        Conexion conexion = new Conexion();
        Connection con = (Connection) conexion.getConn();

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, usuarios.getnombreus());
            ps.setString(2, usuarios.getapellido());
            ps.setString(3, usuarios.getdocumento());
            ps.setString(4, usuarios.gettelefono());
            ps.setString(5, usuarios.getcorreo());
            ps.setInt(6, usuarios.getTipo_documento_id_Tipodocumento());
            ps.setInt(8, usuarios.getRol_id_Rol());
            ps.setInt(9, usuarios.getid_Usuarios());

            if (ps.executeUpdate() > 0) {
                actualizado = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar el usuario: " + e.getMessage());
        }
        return actualizado;
    }


    public boolean eliminarUsuario(int id) throws SQLException {
        boolean eliminado = false;
        String sql = "DELETE FROM usuarios WHERE id_Usuarios = ?";
        Conexion conexion = new Conexion();
        Connection con = (Connection) conexion.getConn();

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            if (ps.executeUpdate() > 0) {
                eliminado = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar el usuario: " + e.getMessage());
        }
        return eliminado;
    }
}  
    
    
    
    
    
    
    
    
    
    
    
