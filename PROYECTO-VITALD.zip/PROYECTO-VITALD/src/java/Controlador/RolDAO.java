/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Rol;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Aprendiz
 */
public class RolDAO {
       Conexion conexion = new Conexion();

   public boolean insertarRol(Rol rol) throws SQLException {
    boolean insertado = false;
    String sql = "INSERT INTO rol (id_Rol, descripcion_rol) VALUES (?, ?)";
    
    try (Connection con = conexion.getConn();
         PreparedStatement ps = con.prepareStatement(sql)) {
        
        ps.setInt(1, rol.getid_Rol());
        ps.setString(2, rol.getdescripcion_rol());

        int filasAfectadas = ps.executeUpdate();
        if (filasAfectadas > 0) {
            insertado = true;
            System.out.println("Rol insertado correctamente");
        }
        
    } catch (SQLException e) {
        System.err.println("Error al insertar Rol: " + e.getMessage());
    }
    return insertado;
}
    
    
    
    public Rol consultaRol(int id_Rol) {

        Rol rol = null;
        Conexion conexion = new Conexion();
        Connection con = conexion.getConn();

        try {

            String querySQL = "SELECT id_Rol, descripcion_rol FROM Rol WHERE id_Rol = ? ";

            PreparedStatement ps = con.prepareStatement(querySQL);
            ps.setInt(1, id_Rol);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                rol = new Rol();
                rol.setid_Rol(rs.getInt(1));
                rol.setdescripcion_rol(rs.getString(2));
            }

            return rol;

        } catch (Exception ex) {

            System.out.println(ex.getMessage());
            return rol;

        }
    }
    
  public boolean actualizarUsuario(Rol rol) throws SQLException {
        boolean actualizado = false;
        String sql = "UPDATE Rol SET descripcion_rol=? WHERE id_Rol=?";
        Conexion conexion = new Conexion();
        Connection con = (Connection) conexion.getConn();

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, rol.getdescripcion_rol());

            if (ps.executeUpdate() > 0) {
                actualizado = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar el rol: " + e.getMessage());
        }
        return actualizado;
    }


    public boolean eliminarRol(int id) throws SQLException {
        boolean eliminado = false;
        String sql = "DELETE FROM rol WHERE id_Rol = ?";
        Conexion conexion = new Conexion();
        Connection con = (Connection) conexion.getConn();

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            if (ps.executeUpdate() > 0) {
                eliminado = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar rol:  " + e.getMessage());
        }
        return eliminado;
    }
}  
